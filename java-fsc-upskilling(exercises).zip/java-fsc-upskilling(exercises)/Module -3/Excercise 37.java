
public class MyClass {
    public void sayHello() {
        System.out.println("Hello");
    }
}
