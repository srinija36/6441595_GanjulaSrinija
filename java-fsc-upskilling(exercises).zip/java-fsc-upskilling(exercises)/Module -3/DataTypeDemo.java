// DataTypeDemo.java
public class DataTypeDemo {
    public static void main(String[] args) {
        int intVal = 25;
        float floatVal = 3.14f;
        double doubleVal = 9.81;
        char charVal = 'A';
        boolean boolVal = true;

        System.out.println("int: " + intVal);
        System.out.println("float: " + floatVal);
        System.out.println("double: " + doubleVal);
        System.out.println("char: " + charVal);
        System.out.println("boolean: " + boolVal);
    }
}
